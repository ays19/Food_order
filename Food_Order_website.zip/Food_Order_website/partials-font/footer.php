 <!-- social Section Starts Here -->
    <section class="social">
        <div class="container text-center">
            <ul>
                <li>
                    <a href="https://www.facebook.com/profile.php?id=100006954281657"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
                </li>
                <li>
                    <a href="https://www.instagram.com/accounts/login/?next=/oishe_alam_ash/"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
                </li>
                <li>
                    <a href="https://twitter.com/NafizulHaque2?t=TjvltzLm5KJmvL_kQhSiew&s=09&fbclid=IwAR2RB65uFqLqyCvk5AqjKojPMTIDkUKRZ06-RrqnoZs-JSs_tPZ_ihD401g"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
                </li>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->

    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
            <p>All rights reserved. Designed By <a href="#">SNO</a></p>
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>