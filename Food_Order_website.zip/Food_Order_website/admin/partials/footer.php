<!-- Footer section Starts -->
<div class="footer">
 	<div class="wrapper">
 	<p class="text-center">2022 All Rights Reserved, FOOD Restaurent, Developed By - <a href="#"> SNO </a></p>
 </div>
 </div>
<!-- Footer section ends -->

</body>
</html>